# Nerf Homework

This implementation is based on [NVlabs/instant-ngp: Instant neural graphics primitives: lightning fast NeRF and more (github.com)](https://github.com/NVlabs/instant-ngp)

To run this project, please run `instant-ngp.exe`

and drag the file ./data/nerf/zhongli into the window
